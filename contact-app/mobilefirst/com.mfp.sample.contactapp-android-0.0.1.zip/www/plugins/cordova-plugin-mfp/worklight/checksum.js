var WL_CHECKSUM = {"checksum":1259124885,"date":1481025580149,"machine":"mbp-de-fred.boiscolombes.fr.ibm.com"}
/* Date: Tue Dec 06 2016 12:59:40 GMT+0100 (CET) */