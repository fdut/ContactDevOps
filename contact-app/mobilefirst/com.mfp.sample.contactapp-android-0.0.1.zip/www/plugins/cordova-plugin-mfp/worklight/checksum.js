var WL_CHECKSUM = {"checksum":1810151820,"date":1480946451646,"machine":"MacBook-Pro-de-fred.local"}
/* Date: Mon Dec 05 2016 15:00:51 GMT+0100 (CET) */