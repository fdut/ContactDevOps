var WL_CHECKSUM = {"checksum":3005210668,"date":1490962053983,"machine":"MBP-de-fred"}
/* Date: Fri Mar 31 2017 14:07:33 GMT+0200 (CEST) */